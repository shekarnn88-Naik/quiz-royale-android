package com.example.hindiquizchallenge

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate

private data class Q(
    val category: String,
    val hi: String,
    val en: String,
    val optionsHi: List<String>,
    val optionsEn: List<String>,
    val answer: Int,
    val explainHi: String,
    val explainEn: String,
    val difficulty: String = "Easy"
)

private val bank = listOf(
    Q("India","भारत का राष्ट्रीय पशु कौन-सा है?","What is the national animal of India?", listOf("शेर","बाघ","हाथी","तेंदुआ"),listOf("Lion","Tiger","Elephant","Leopard"),1,"बाघ भारत का राष्ट्रीय पशु है।","The tiger is India's national animal."),
    Q("Science","पौधे अपना भोजन किस प्रक्रिया से बनाते हैं?","How do plants make their food?",listOf("श्वसन","प्रकाश संश्लेषण","वाष्पीकरण","पाचन"),listOf("Respiration","Photosynthesis","Evaporation","Digestion"),1,"हरे पौधे प्रकाश संश्लेषण करते हैं।","Green plants make food through photosynthesis."),
    Q("History","भारत को स्वतंत्रता कब मिली?","When did India become independent?",listOf("26 जनवरी 1950","15 अगस्त 1947","2 अक्टूबर 1947","15 अगस्त 1950"),listOf("26 Jan 1950","15 Aug 1947","2 Oct 1947","15 Aug 1950"),1,"भारत 15 अगस्त 1947 को स्वतंत्र हुआ।","India became independent on 15 August 1947."),
    Q("Sports","क्रिकेट की एक टीम में कितने खिलाड़ी होते हैं?","How many players are there in a cricket team?",listOf("9","10","11","12"),listOf("9","10","11","12"),2,"क्रिकेट टीम में 11 खिलाड़ी होते हैं।","A cricket team has 11 players."),
    Q("India","भारत की राजधानी क्या है?","What is the capital of India?",listOf("मुंबई","नई दिल्ली","कोलकाता","चेन्नई"),listOf("Mumbai","New Delhi","Kolkata","Chennai"),1,"भारत की राजधानी नई दिल्ली है।","New Delhi is the capital of India."),
    Q("Science","पानी का रासायनिक सूत्र क्या है?","What is the chemical formula of water?",listOf("CO2","O2","H2O","NaCl"),listOf("CO2","O2","H2O","NaCl"),2,"पानी का सूत्र H₂O है।","The chemical formula of water is H₂O."),
    Q("History","ताजमहल किसने बनवाया था?","Who commissioned the Taj Mahal?",listOf("अकबर","शाहजहाँ","जहाँगीर","बाबर"),listOf("Akbar","Shah Jahan","Jahangir","Babur"),1,"ताजमहल शाहजहाँ ने बनवाया था।","The Taj Mahal was commissioned by Shah Jahan."),
    Q("Sports","ओलंपिक प्रतीक में कितने छल्ले होते हैं?","How many rings are in the Olympic symbol?",listOf("4","5","6","7"),listOf("4","5","6","7"),1,"ओलंपिक प्रतीक में पाँच छल्ले हैं।","The Olympic symbol has five rings."),
    Q("Entertainment","हिंदी फिल्म उद्योग को आमतौर पर क्या कहा जाता है?","What is the Hindi film industry commonly called?",listOf("हॉलीवुड","बॉलीवुड","टॉलीवुड","कॉलीवुड"),listOf("Hollywood","Bollywood","Tollywood","Kollywood"),1,"हिंदी फिल्म उद्योग को बॉलीवुड कहा जाता है।","The Hindi film industry is commonly called Bollywood."),
    Q("India","भारत का राष्ट्रीय फूल कौन-सा है?","What is the national flower of India?",listOf("गुलाब","कमल","गेंदा","चमेली"),listOf("Rose","Lotus","Marigold","Jasmine"),1,"कमल भारत का राष्ट्रीय फूल है।","The lotus is India's national flower."),
    Q("Science","सौरमंडल का सबसे बड़ा ग्रह कौन-सा है?","Which is the largest planet in our solar system?",listOf("पृथ्वी","मंगल","बृहस्पति","शुक्र"),listOf("Earth","Mars","Jupiter","Venus"),2,"बृहस्पति सौरमंडल का सबसे बड़ा ग्रह है।","Jupiter is the largest planet in our solar system."),
    Q("India","भारत का संविधान कब लागू हुआ?","When did the Constitution of India come into effect?",listOf("15 अगस्त 1947","26 जनवरी 1950","2 अक्टूबर 1950","26 नवंबर 1949"),listOf("15 Aug 1947","26 Jan 1950","2 Oct 1950","26 Nov 1949"),1,"संविधान 26 जनवरी 1950 को लागू हुआ।","The Constitution came into effect on 26 January 1950."),
    Q("Science","मानव शरीर में रक्त पंप करने वाला अंग कौन-सा है?","Which organ pumps blood through the human body?",listOf("फेफड़े","हृदय","गुर्दे","यकृत"),listOf("Lungs","Heart","Kidneys","Liver"),1,"हृदय रक्त पंप करता है।","The heart pumps blood through the body."),
    Q("History","महात्मा गांधी का जन्मदिन कब मनाया जाता है?","When is Mahatma Gandhi's birthday observed?",listOf("14 नवंबर","2 अक्टूबर","15 अगस्त","26 जनवरी"),listOf("14 November","2 October","15 August","26 January"),1,"गांधी जयंती 2 अक्टूबर को मनाई जाती है।","Gandhi Jayanti is observed on 2 October."),
    Q("Sports","फुटबॉल में एक टीम के कितने खिलाड़ी मैदान पर होते हैं?","How many players from one team are on the field in football?",listOf("9","10","11","12"),listOf("9","10","11","12"),2,"फुटबॉल टीम के 11 खिलाड़ी मैदान पर होते हैं।","A football team has 11 players on the field."),
    Q("India","भारत का राष्ट्रीय जलीय जीव कौन-सा है?","What is India's national aquatic animal?",listOf("मगरमच्छ","गंगा नदी डॉल्फिन","कछुआ","नीली व्हेल"),listOf("Crocodile","Ganges river dolphin","Turtle","Blue whale"),1,"गंगा नदी डॉल्फिन भारत का राष्ट्रीय जलीय जीव है।","The Ganges river dolphin is India's national aquatic animal."),
    Q("Science","सूर्य के सबसे निकट कौन-सा ग्रह है?","Which planet is closest to the Sun?",listOf("शुक्र","पृथ्वी","बुध","मंगल"),listOf("Venus","Earth","Mercury","Mars"),2,"बुध सूर्य के सबसे निकट ग्रह है।","Mercury is the closest planet to the Sun."),
    Q("History","कुतुब मीनार किस शहर में है?","In which city is the Qutub Minar located?",listOf("आगरा","दिल्ली","जयपुर","लखनऊ"),listOf("Agra","Delhi","Jaipur","Lucknow"),1,"कुतुब मीनार दिल्ली में स्थित है।","The Qutub Minar is in Delhi."),
    Q("Entertainment","ऑस्कर पुरस्कार किस क्षेत्र से संबंधित हैं?","The Oscars are awards for which field?",listOf("खेल","सिनेमा","विज्ञान","साहित्य"),listOf("Sports","Cinema","Science","Literature"),1,"ऑस्कर फिल्म उद्योग के प्रमुख पुरस्कार हैं।","The Oscars are major awards in the film industry."),
    Q("Sports","शतरंज की बिसात में कुल कितने खाने होते हैं?","How many squares are on a chessboard?",listOf("ัป  เข  36","49","64","81"),listOf("36","49","64","81"),2,"शतरंज की बिसात में 64 खाने होते हैं।","A chessboard has 64 squares.", "Medium"),
    Q("Science","प्रकाश की गति लगभग कितनी है?","Approximately what is the speed of light?",listOf("3 लाख किमी/सेकंड","30 हजार किमी/सेकंड","300 किमी/सेकंड","3 हजार किमी/सेकंड"),listOf("300,000 km/s","30,000 km/s","300 km/s","3,000 km/s"),0,"निर्वात में प्रकाश की गति लगभग 3 लाख किमी/सेकंड है।","Light travels at about 300,000 km/s in vacuum.", "Hard")
)

private val bgTop = Color(0xFF100D2B)
private val bgBottom = Color(0xFF30216B)
private val gold = Color(0xFFFFC857)
private val violet = Color(0xFF8067FF)
private val panel = Color(0xFF211B48)
private val muted = Color(0xFFBDB6E4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoyaleApp(this) }
    }
}

@Composable
private fun RoyaleApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("quiz_royale", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf("home") }
    var english by remember { mutableStateOf(prefs.getBoolean("english", false)) }
    var category by remember { mutableStateOf("All") }
    var difficulty by remember { mutableStateOf("All") }
    var game by remember { mutableStateOf(bank.shuffled().take(10)) }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var best by remember { mutableIntStateOf(prefs.getInt("best", 0)) }
    var seconds by remember { mutableIntStateOf(15) }
    var chosen by remember { mutableIntStateOf(-1) }
    var answered by remember { mutableStateOf(false) }
    var daily by remember { mutableStateOf(false) }

    LaunchedEffect(screen, index, answered) {
        if (screen == "quiz" && !answered) {
            seconds = 15
            while (seconds > 0 && !answered) {
                delay(1000)
                seconds--
            }
            if (seconds == 0 && !answered) answered = true
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = violet, background = bgTop)) {
        Box(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bgTop, bgBottom, Color(0xFF17123B)))).padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            when (screen) {
                "home" -> Home(
                    english, { english = it; prefs.edit().putBoolean("english", it).apply() },
                    best, category, { category = it }, difficulty, { difficulty = it },
                    onStart = { isDaily ->
                        daily = isDaily
                        val filtered = bank.filter {
                            (category == "All" || it.category == category) &&
                            (difficulty == "All" || it.difficulty == difficulty)
                        }
                        game = (if (filtered.isEmpty()) bank else filtered).shuffled().take(10)
                        index = 0; score = 0; chosen = -1; answered = false
                        screen = "quiz"
                    }
                )
                "quiz" -> Quiz(
                    game[index], index, game.size, score, seconds, chosen, answered, english,
                    onChoose = { option ->
                        if (!answered) {
                            chosen = option; answered = true
                            if (option == game[index].answer) score += if (seconds > 10) 15 else 10
                        }
                    },
                    onNext = {
                        if (index < game.lastIndex) { index++; chosen = -1; answered = false }
                        else {
                            if (score > best) {
                                best = score
                                prefs.edit().putInt("best", best).apply()
                            }
                            screen = "result"
                        }
                    }
                )
                "result" -> Result(score, game.size, best, english, daily) { screen = "home" }
            }
        }
    }
}

@Composable
private fun Home(
    english: Boolean, onLanguage: (Boolean) -> Unit, best: Int,
    category: String, onCategory: (String) -> Unit,
    difficulty: String, onDifficulty: (String) -> Unit,
    onStart: (Boolean) -> Unit
) {
    val categories = listOf("All","India","Science","History","Sports","Entertainment")
    Column(
        Modifier.fillMaxWidth().background(panel, RoundedCornerShape(28.dp)).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("QUIZ ROYALE", color = gold, fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontSize = 13.sp)
            TextButton(onClick = { onLanguage(!english) }) {
                Text(if (english) "हिन्दी" else "ENGLISH", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("👑", fontSize = 52.sp)
        Text(if (english) "THE QUIZ ARENA" else "क्विज़ का मैदान", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Text(if (english) "Play smart. Rise to the top." else "ज्ञान दिखाओ • स्कोर बढ़ाओ • जीत हासिल करो", color = muted, fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat(if (english) "BEST SCORE" else "बेस्ट स्कोर", "$best")
            Stat(if (english) "QUESTION BANK" else "कुल सवाल", "${bank.size}+")
            Stat(if (english) "MODE" else "मोड", "OFFLINE")
        }
        Spacer(Modifier.height(20.dp))
        Text(if (english) "CHOOSE CATEGORY" else "श्रेणी चुनें", color = gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        categories.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                row.forEach { c ->
                    val label = if (english) c else when(c) {
                        "All" -> "सभी"; "India" -> "भारत"; "Science" -> "विज्ञान"
                        "History" -> "इतिहास"; "Sports" -> "खेल"; else -> "मनोरंजन"
                    }
                    SelectChip(label, category == c, Modifier.weight(1f)) { onCategory(c) }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
        Text(if (english) "DIFFICULTY" else "कठिनाई", color = gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("All","Easy","Medium","Hard").forEach { d ->
                val label = if (english) d else when(d) { "All" -> "सभी"; "Easy" -> "आसान"; "Medium" -> "मध्यम"; else -> "कठिन" }
                SelectChip(label, difficulty == d, Modifier.weight(1f)) { onDifficulty(d) }
            }
        }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { onStart(false) }, modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color(0xFF25183E)),
            shape = RoundedCornerShape(16.dp)
        ) { Text(if (english) "▶  PLAY NOW" else "▶  खेल शुरू करें", fontWeight = FontWeight.Black, fontSize = 16.sp) }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { onStart(true) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text(if (english) "✦  DAILY CHALLENGE" else "✦  आज की चुनौती", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        AdPlaceholder(english)
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = gold, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Text(label, color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SelectChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.background(if (selected) violet else Color(0xFF332B60), RoundedCornerShape(11.dp))
            .clickable { onClick() }.padding(vertical = 10.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
}

@Composable
private fun AdPlaceholder(english: Boolean) {
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF181337), RoundedCornerShape(10.dp)).padding(9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(if (english) "AD SPACE • TEST PLACEHOLDER" else "विज्ञापन स्थान • टेस्ट प्लेसहोल्डर", color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(if (english) "AdMob can be connected before release" else "लॉन्च से पहले AdMob जोड़ा जा सकता है", color = muted, fontSize = 9.sp)
    }
}

@Composable
private fun Quiz(
    q: Q, index: Int, total: Int, score: Int, seconds: Int, chosen: Int,
    answered: Boolean, english: Boolean, onChoose: (Int) -> Unit, onNext: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(25.dp)).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${index + 1}/$total", color = gold, fontWeight = FontWeight.Black)
            Text("⭐ $score", color = gold, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(progress = { (index + 1f) / total }, modifier = Modifier.fillMaxWidth(), color = gold, trackColor = Color(0xFF49406F))
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(q.category.uppercase(), color = muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("⏱ $seconds", color = if (seconds <= 5) Color(0xFFFF7676) else gold, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Text(if (english) q.en else q.hi, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 30.sp)
        Spacer(Modifier.height(18.dp))
        val opts = if (english) q.optionsEn else q.optionsHi
        opts.forEachIndexed { i, option ->
            val color = when {
                answered && i == q.answer -> Color(0xFF1F7655)
                answered && i == chosen -> Color(0xFF9A3D50)
                chosen == i -> violet
                else -> Color(0xFF332B60)
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 5.dp).background(color, RoundedCornerShape(13.dp))
                    .clickable(enabled = !answered) { onChoose(i) }.padding(15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${'A' + i}", color = gold, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(12.dp))
                Text(option, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            }
        }
        if (answered) {
            Spacer(Modifier.height(10.dp))
            Text(
                if (chosen == q.answer) { if (english) "CORRECT! +${if (seconds > 10) 15 else 10} POINTS" else "सही जवाब! +${if (seconds > 10) 15 else 10} अंक" }
                else { if (english) "Correct answer: ${q.optionsEn[q.answer]}" else "सही जवाब: ${q.optionsHi[q.answer]}" },
                color = gold, fontWeight = FontWeight.Bold
            )
            Text(if (english) q.explainEn else q.explainHi, color = muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onNext, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color(0xFF25183E))) {
                Text(if (index == total - 1) { if (english) "VIEW RESULTS" else "परिणाम देखें" } else { if (english) "NEXT QUESTION →" else "अगला सवाल →" }, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun Result(score: Int, total: Int, best: Int, english: Boolean, daily: Boolean, onHome: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(28.dp)).padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🏆", fontSize = 60.sp)
        Text(if (english) "CHALLENGE COMPLETE" else "चुनौती पूरी हुई", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text("$score", color = gold, fontSize = 54.sp, fontWeight = FontWeight.Black)
        Text(if (english) "POINTS • MAX ${total * 15}" else "अंक • अधिकतम ${total * 15}", color = muted, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            when {
                score >= total * 12 -> if (english) "LEGENDARY PERFORMANCE!" else "जबरदस्त प्रदर्शन!"
                score >= total * 7 -> if (english) "GREAT GAME!" else "बहुत शानदार!"
                else -> if (english) "KEEP PRACTISING!" else "अभ्यास जारी रखें!"
            }, color = gold, fontWeight = FontWeight.Bold, fontSize = 19.sp
        )
        Text(if (english) "Personal best: $best" else "आपका बेस्ट स्कोर: $best", color = muted)
        if (daily) Text(if (english) "Daily challenge completed" else "आज की चुनौती पूरी हुई", color = muted, fontSize = 12.sp)
        Spacer(Modifier.height(22.dp))
        Button(onClick = onHome, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color(0xFF25183E))) {
            Text(if (english) "BACK TO ARENA" else "होम स्क्रीन पर जाएँ", fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(12.dp))
        AdPlaceholder(english)
    }
}
