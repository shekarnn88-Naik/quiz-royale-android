# Quiz Royale / Hindi Quiz Challenge — Version 2

## What's included
- Android native app using Kotlin + Jetpack Compose
- Hindi / English language toggle
- Premium dark gaming-inspired interface
- Category selection: India, Science, History, Sports, Entertainment
- Difficulty filter: Easy, Medium, Hard
- 15-second question timer
- Faster correct answers earn a small time bonus
- Explanations after answers
- Personal best score saved locally on the device
- Daily challenge entry point
- Offline question bank; no account, server, or paid API
- Clearly marked ad placeholder areas

## Important scope notes
- This is a playable MVP starter project with a small sample bank (20 questions), not the promised production library of 1,000 reviewed questions.
- The daily challenge currently starts a quiz session; it does not yet enforce one attempt per calendar day.
- AdMob is NOT integrated. The placeholder is intentional: live ads require an AdMob account, app registration, ad unit IDs, consent/privacy setup where applicable, and testing with Google's test ad units.
- No real-money rewards, cash prizes, or leaderboard backend are included.

## Run
1. Install Android Studio.
2. Open this folder in Android Studio.
3. Use JDK 17 and install Android SDK 35 if prompted.
4. Sync Gradle and run on an emulator or Android phone.
5. Build APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

This source project has not been compiled or tested on a physical device in this environment. Resolve any Android Studio / Gradle issues and test thoroughly before public release.
